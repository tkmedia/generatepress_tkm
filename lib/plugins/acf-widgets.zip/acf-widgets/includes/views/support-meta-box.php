<h4><?php _e('General Support'); ?></h4>
<p><?php printf(__('Check out the official %s Support Forums %s', 'acfw'), '<a href="http://acfwidgets.com/support/">', '</a>'); ?></p>
<hr />
<h4><?php _e('Looking for Priority Support?', 'acfw'); ?></h4>
<p><?php printf(__('Check out the %s Priority Support Forums %s', 'acfw'), '<a href="http://acfwidgets.com/support/forum/priority-support/">', '</a>'); ?></p>